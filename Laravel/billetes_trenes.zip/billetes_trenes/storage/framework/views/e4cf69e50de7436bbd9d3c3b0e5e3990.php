<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h1>Crear un nuevo ticket</h1>
    <form action="<?php echo e(route('tickets.index')); ?>" method="get">
        <input type="submit" value="Volver a inicio">
    </form>
    <br><br>
    <form action="<?php echo e(route('tickets.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <label for="date">Fecha</label>
        <input type="date" name="date">
        <br><br>
        <label for="price">Precio</label>
        <input type="number" step="0.5" name="price">
        <br><br>
        <select name="train" id="train">
            <?php $__currentLoopData = $trains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($train->id); ?>"><?php echo e($train->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br><br>
        <select name="ticket_type" id="ticket_type">
            <?php $__currentLoopData = $ticket_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($ticket_type->id); ?>"><?php echo e($ticket_type->type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br><br>
        <input type="submit" value="Crear">
    </form>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ejercicios\ComienzosEnPHP\Laravel\billetes_trenes\resources\views//tickets/create.blade.php ENDPATH**/ ?>