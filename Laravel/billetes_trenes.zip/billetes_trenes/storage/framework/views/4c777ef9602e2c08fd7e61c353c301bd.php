<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Ticket <?php echo e($ticket->id); ?></h1>
    <h3>Fecha: <?php echo e($ticket->date); ?></h3>
    <h3>Nombre del tren: <?php echo e($ticket->train_name->name); ?></h3>
    <h3>Tipo de billete: <?php echo e($ticket->ticket_type->type); ?></h3>
</body>
</html><?php /**PATH C:\xampp\htdocs\ejercicios\ComienzosEnPHP\Laravel\billetes_trenes\resources\views//tickets/show.blade.php ENDPATH**/ ?>