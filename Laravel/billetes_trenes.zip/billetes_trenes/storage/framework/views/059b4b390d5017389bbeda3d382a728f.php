<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h1>Editar tren <?php echo e($train->id); ?></h1>
    <form action="<?php echo e(route('trains.index')); ?>" method="get">
        <input type="submit" value="Volver a inicio">
    </form>
    <br><br>
    <form action="<?php echo e(route('trains.update', ['train' => $train->id])); ?>" method="post">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <label for="name">Nombre</label>
        <input type="text" name="name" value="<?php echo e($train->name); ?>">
        <br><br>
        <label for="passengers">Pasajeros</label>
        <input type="number" step="1" name="passengers" value="<?php echo e($train->passengers); ?>">
        <br><br>
        <label for="year">Año del tren</label>
        <input type="number" step="1" name="year" value="<?php echo e($train->year); ?>">
        <br><br>
        <select name="train_type" id="train">
            <?php $__currentLoopData = $train_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option <?php if($train->train_type_id == $train_type->id): ?> selected <?php endif; ?> value="<?php echo e($train_type->id); ?>">
                    <?php echo e($train_type->type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <input type="submit" value="Editar">
    </form>
</body>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ejercicios\ComienzosEnPHP\Laravel\billetes_trenes\resources\views//trains/edit.blade.php ENDPATH**/ ?>