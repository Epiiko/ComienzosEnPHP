<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h1>Tipo de tickets</h1>
    <table border="2">
        <thead>
            <tr>
                <th>Tipos de ticket</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $ticket_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ticket_type->type); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <br>
    <br>
    <form action="<?php echo e(route('trains.index')); ?>" method="get" style="display: inline">
        <input type="submit" value="Ver trenes">
    </form>
    <form action="<?php echo e(route('train_types.index')); ?>" method="get"style="display: inline">
        <input type="submit" value="Ver tipo de trenes">
    </form>
    <form action="<?php echo e(route('tickets.index')); ?>" method="get" style="display: inline">
        <input type="submit" value="Ver tickets">
    </form>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ejercicios\ComienzosEnPHP\Laravel\billetes_trenes\resources\views//ticket_types/index.blade.php ENDPATH**/ ?>