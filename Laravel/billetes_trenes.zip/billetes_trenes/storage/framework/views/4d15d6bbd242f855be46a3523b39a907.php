<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>Listado de trenes</h1>
    <form action="<?php echo e(route('trains.create')); ?>" method="get">
        <input type="submit" value="Crear nuevo train">
    </form>
    <br><br>
    <table border="2">
        <thead>
            <tr>
                <th>Name</th>
                <th>Pasajeros</th>
                <th>Año del tren</th>
                <th>Tipo de tren</th>
                <th colspan="3">RUD</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $trains; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $train): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($train->name); ?></td>
                    <td><?php echo e($train->passengers); ?></td>
                    <td><?php echo e($train->year); ?></td>
                    <td><?php echo e($train->train_type->type); ?></td>
                    <td>
                        <form action="<?php echo e(route('trains.show', ['train' => $train->id])); ?>" method="get">
                            <input type="submit" value="Ver">
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('trains.edit', ['train' => $train->id])); ?>" method="get">
                            <input type="submit" value="Editar">
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('trains.destroy', ['train' => $train->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <br>
    <br>
    </form>
    <form action="<?php echo e(route('train_types.index')); ?>" method="get"style="display: inline">
        <input type="submit" value="Ver tipo de trenes">
    </form>
    <form action="<?php echo e(route('ticket_types.index')); ?>" method="get" style="display: inline">
        <input type="submit" value="Ver tipo de tickets">
    </form>
    <form action="<?php echo e(route('tickets.index')); ?>" method="get" style="display: inline">
        <input type="submit" value="Ver tickets">
    </form>
</body>
</html><?php /**PATH C:\xampp\htdocs\ejercicios\ComienzosEnPHP\Laravel\billetes_trenes\resources\views//trains/index.blade.php ENDPATH**/ ?>