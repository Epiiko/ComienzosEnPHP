<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h1>Bienvenido al historial de Tickets</h1>
    <form action="<?php echo e(route('tickets.create')); ?>" method="get">
        <input type="submit" value="Crear nuevo ticket">
    </form>
    <br><br>
    <table border="2">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Precio</th>
                <th>Nº Tren</th>
                <th>Tipo de billete</th>
                <th colspan="3">RUD</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($ticket->date); ?></td>
                    <td><?php echo e($ticket->price); ?></td>
                    <td><?php echo e($ticket->train_name->name); ?></td>
                    <td><?php echo e($ticket->ticket_type->type); ?></td>
                    <td>
                        <form action="<?php echo e(route('tickets.show', ['ticket' => $ticket->id])); ?>" method="get">
                            <input type="submit" value="Ver">
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('tickets.edit', ['ticket' => $ticket->id])); ?>" method="get">
                            <input type="submit" value="Editar">
                        </form>
                    </td>
                    <td>
                        <form action="<?php echo e(route('tickets.destroy', ['ticket' => $ticket->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('DELETE')); ?>

                            <input type="submit" value="Eliminar">
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <br>
    <br>
    <form action="<?php echo e(route('trains.index')); ?>" method="get" style="display: inline">
        <input type="submit" value="Ver trenes">
    </form>
    <form action="<?php echo e(route('train_types.index')); ?>" method="get"style="display: inline">
        <input type="submit" value="Ver tipo de trenes">
    </form>
    <form action="<?php echo e(route('ticket_types.index')); ?>" method="get" style="display: inline">
        <input type="submit" value="Ver tipo de tickets">
    </form>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\ejercicios\ComienzosEnPHP\Laravel\billetes_trenes\resources\views//tickets/index.blade.php ENDPATH**/ ?>