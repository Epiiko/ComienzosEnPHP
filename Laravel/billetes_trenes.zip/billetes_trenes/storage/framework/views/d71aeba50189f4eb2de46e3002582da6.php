<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form action="<?php echo e(route('trains.index')); ?>" method="get">
        <input type="submit" value="Volver a inicio">
    </form>
    <h1>Nombre <?php echo e($train->name); ?></h1>
    <h3>Capacidad para: <?php echo e($train->passengers); ?> pasajeros</h3>
    <h3>Año del tren: <?php echo e($train->year); ?></h3>
    <h3>Tipo de tren: <?php echo e($train->train_type->type); ?></h3>
</body>
</html><?php /**PATH C:\xampp\htdocs\ejercicios\ComienzosEnPHP\Laravel\billetes_trenes\resources\views//trains/show.blade.php ENDPATH**/ ?>